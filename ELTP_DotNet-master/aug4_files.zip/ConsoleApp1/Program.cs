﻿Console.WriteLine("<===============Aug 4 files assignment==================>");
Console.WriteLine();


string? continueExecution = "y";
do
{
    Console.WriteLine("Enter your choice to perform operation");
    Console.WriteLine("===========================================================================");
    Console.WriteLine();

    Console.WriteLine("1. Get Deatils of particular File.");
    Console.WriteLine("2. Image to Byte Array.");
    Console.WriteLine("3. Files from Directory and Sub-Directory.");
    Console.WriteLine("4. Copy Files from one Directory to another.");


    Console.WriteLine();


    int choice = Convert.ToInt32(Console.ReadLine());
    Console.WriteLine();
    switch (choice)
    {
        case 1:

            {
                DirectoryInfo place = new DirectoryInfo(@"C:\Users\coditas\Desktop\data");

                FileInfo[] Files = place.GetFiles();
                Console.WriteLine("Files are:");
                Console.WriteLine();

                // Display the file names
                foreach (FileInfo i in Files)
                {
                    Console.WriteLine(i.Name);
                }

                //gettings deatils of the files
                Console.WriteLine();
                Console.WriteLine("Please enter FileName to get details: ");
                string fileName = Console.ReadLine();
                string path = @"C:\Users\coditas\Desktop\data\" + fileName;
                Console.WriteLine();


                FileInfo extension = new FileInfo(path);

                Console.WriteLine("File Path : " + extension.FullName);
                Console.WriteLine("File Name : " + extension.Name);
                Console.WriteLine("File Extension : " + extension.Extension);
                Console.WriteLine("File Size : " + extension.Length);
                Console.WriteLine("File Created : " + extension.CreationTime);
                Console.WriteLine("File Modified : " + extension.LastWriteTime);
                Console.WriteLine("Last File Accessed : " + extension.LastAccessTime);
                Console.WriteLine("File Mode (Read) : " + extension.IsReadOnly);

                break;
            }


        case 2:
            {
                break;
            }

        case 3:
            {
                DirectoryInfo place = new DirectoryInfo(@"C:\Users\coditas\Desktop\data");

                FileInfo[] Files = place.GetFiles();
                Console.WriteLine("Files in Directory are:");
                Console.WriteLine();


                // Display the file names
                Console.WriteLine(" Name         Ext.         Size            Created              Modified");
                foreach (FileInfo i in Files)
                {
                    Console.WriteLine("{0}      {1}         {2}         {3}        {4} ", i.Name, i.Extension, i.Length, i.CreationTime, i.LastWriteTime);
                }

                string path = @"C:\Users\coditas\Desktop\data";
                if (System.IO.Directory.GetDirectories(path).Length > 0)
                {
                    Console.WriteLine();
                    Console.WriteLine("Directory has Sub-Directory whose files are : ");


                    //remaining files to be accessed from sub-directories

                    string[] dirs = Directory.GetDirectories(path);
                    Console.WriteLine(String.Join(Environment.NewLine, dirs));

                }
                break;
            }


            case 4:
            {
                string source_dir = @"C:\Users\coditas\Desktop\data";
                string destination_dir = @"C:\Users\coditas\Desktop\copied";


                foreach (string dir in System.IO.Directory.GetDirectories(source_dir, "*", System.IO.SearchOption.AllDirectories))
                {
                    System.IO.Directory.CreateDirectory(System.IO.Path.Combine(destination_dir, dir.Substring(source_dir.Length + 1)));
                    
                }

                foreach (string file_name in System.IO.Directory.GetFiles(source_dir, "*", System.IO.SearchOption.AllDirectories))
                {
                    System.IO.File.Copy(file_name, System.IO.Path.Combine(destination_dir, file_name.Substring(source_dir.Length + 1)));
                }

                Console.WriteLine("Files Coiped Sucessfully!! ");
                break;
            }
    }

    Console.WriteLine("Please enter y or Y to continue");
            continueExecution = Console.ReadLine();
    Console.Clear();
}while (continueExecution == "y" || continueExecution == "Y");









